'use strict';

appModule.controller('notfoundController', function($scope) {
	$scope.a = AppUtil.gethexa(255);
});