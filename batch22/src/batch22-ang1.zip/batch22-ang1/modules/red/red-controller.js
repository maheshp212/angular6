'use strict';

appModule.controller('redController', function($scope, $routeParams) {
	$scope.a = AppUtil.gethexa(255);

	console.log($routeParams);
});