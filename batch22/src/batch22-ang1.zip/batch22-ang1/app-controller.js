'use strict';

appModule.controller('mainAppCtrl', function($location) {
    $location.path('/green');
});