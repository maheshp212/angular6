'use strict';

appModule.controller(' homeController', function($scope) {
	$scope.a = AppUtil.gethexa(16);

});
