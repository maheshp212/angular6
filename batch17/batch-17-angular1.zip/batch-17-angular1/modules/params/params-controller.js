'use strict';

appModule.controller('paramsController', function($scope, $routeParams) {
	$scope.a = AppUtil.gethexa(16);
	console.log('asdfasdfsadf');
	console.log($routeParams);
	$scope.name = $routeParams.name;
	$scope.id = $routeParams.id;

});
