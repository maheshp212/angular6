'use strict';
var appModule = angular.module('sample-app', ['ngRoute','ngAnimate', 'ngSanitize', 'ui.bootstrap']);


appModule.config(function($routeProvider, $locationProvider) {
    $locationProvider.hashPrefix('');
    $routeProvider
    .when("/", {
        templateUrl : "modules/home/home.html",
        controller: "homeController"
    })
    .when("/red", {
        templateUrl : "modules/red/red.html",
        controller: "redController"
    })
    .when("/green", {
        templateUrl : "modules/green/green.html"
    })
    .when("/contact/:name/:id", {
        templateUrl : "modules/params/params.html",
        controller: "paramsController"
    })
    .otherwise({
        templateUrl : "modules/notfound/notfound.html",
        controller: "notfoundController"
    })
    ;
});